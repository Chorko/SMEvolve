// Initialize the map
const map = L.map('map').setView([13.0827, 80.2707], 13); // Default to Chennai coordinates

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '© OpenStreetMap contributors',
}).addTo(map);

// Add a form for user input
const formHtml = `
  <div style="position: absolute; top: 10px; left: 10px; background: white; padding: 10px; z-index: 1000;">
    <label for="start-coordinates">Start (Lat,Lng):</label>
    <input id="start-coordinates" type="text" placeholder="13.0827,80.2707" /><br />
    <label for="end-coordinates">Destination (Lat,Lng):</label>
    <input id="end-coordinates" type="text" placeholder="13.0500,80.2824" /><br />
    <button id="route-btn">Find Route</button>
  </div>
`;

document.body.insertAdjacentHTML('beforeend', formHtml);

let currentRoute; // To store the current route layer

document.getElementById('route-btn').addEventListener('click', async () => {
  const startCoords = document.getElementById('start-coordinates').value.split(',').map(Number);
  const endCoords = document.getElementById('end-coordinates').value.split(',').map(Number);

  if (startCoords.length !== 2 || endCoords.length !== 2 || isNaN(startCoords[0]) || isNaN(startCoords[1]) || isNaN(endCoords[0]) || isNaN(endCoords[1])) {
    alert('Please enter valid coordinates for Start and Destination!');
    return;
  }

  try {
    // Use OpenRouteService API for routing
    const apiKey = 'YOUR_API_KEY'; // Replace with your API key
    const url = `https://api.openrouteservice.org/v2/directions/driving-car?api_key=${apiKey}&start=${startCoords[1]},${startCoords[0]}&end=${endCoords[1]},${endCoords[0]}`;

    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch route data');

    const data = await response.json();
    const coordinates = data.features[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);

    // Remove the previous route
    if (currentRoute) {
      map.removeLayer(currentRoute);
    }

    // Draw the new route
    currentRoute = L.polyline(coordinates, { color: 'blue', weight: 5 }).addTo(map);

    // Zoom to fit the new route
    map.fitBounds(currentRoute.getBounds());
  } catch (error) {
    console.error('Error:', error);
    alert('Failed to fetch the route. Please try again.');
  }
});

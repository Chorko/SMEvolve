const axios = require('axios');

async function getCoordinates(location) {
  const apiKey = process.env.ORS_API_KEY;
  const url = `https://api.openrouteservice.org/geocode/search?api_key=${apiKey}&text=${encodeURIComponent(location)}`;

  const response = await axios.get(url);
  const features = response.data.features;

  if (!features || features.length === 0) {
    throw new Error('No results found for the given location');
  }

  const [lng, lat] = features[0].geometry.coordinates;
  return { lat, lng };
}

module.exports = { getCoordinates };

const express = require('express');
const router = express.Router();
const geocodeService = require('../services/geocodeService');

// Geocoding route
router.get('/', async (req, res) => {
  const { location } = req.query;

  if (!location) {
    return res.status(400).json({ error: 'Location is required' });
  }

  try {
    const coordinates = await geocodeService.getCoordinates(location);
    res.json({ coordinates });
  } catch (error) {
    console.error('Error in geocoding route:', error);
    res.status(500).json({ error: 'Failed to fetch geocoding data' });
  }
});

module.exports = router;

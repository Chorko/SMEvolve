import { NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"

const execAsync = promisify(exec)

export async function POST() {
  try {
    const { stdout, stderr } = await execAsync("python tax.py")

    if (stderr) {
      console.error("Error running Python script:", stderr)
      return NextResponse.json({ error: "Error running analysis: " + stderr }, { status: 500 })
    }

    return NextResponse.json({ output: stdout })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Internal server error: " + error.message }, { status: 500 })
  }
}


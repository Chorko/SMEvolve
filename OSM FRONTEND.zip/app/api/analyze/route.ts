import { NextResponse } from "next/server"
import { MongoClient } from "mongodb"
import axios from "axios"

const MONGODB_URL = "mongodb+srv://chorkoccse2023:11281058@cluster0.b0nh98b.mongodb.net/"
const DB_NAME = "sme_waiver"
const COLLECTION_NAME = "user_details"

const API_KEY = "AIzaSyCTvpqoQvxzUEEdrKVwe88wGHwePryWxj4"
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`

export async function POST(req: Request) {
  try {
    const { businessSector, annualTurnover, subsidies, state } = await req.json()

    // Save to MongoDB
    const client = await MongoClient.connect(MONGODB_URL)
    const db = client.db(DB_NAME)
    const collection = db.collection(COLLECTION_NAME)
    await collection.insertOne({ businessSector, annualTurnover, subsidies, state })
    client.close()

    // Generate analysis using Google Gemini API
    const query = {
      contents: [
        {
          parts: [
            {
              text: `Analyze tax waivers for ${businessSector} in ${state} with ₹${annualTurnover} turnover, availing ${subsidies} subsidies.

          Tax regimes include:

          Food Industry:
          - GST Slabs: 0% (Fresh fruits, vegetables, milk, eggs), 5% (Processed foods), 12% (Packaged foods, frozen goods).
          - Waivers: GST exemption on basic unprocessed foods, Subsidies under PMEGP for food manufacturing units.

          Clothing and Textiles:
          - GST Slabs: 5% (Garments below ₹1000), 12% (Garments above ₹1000).
          - Waivers: Reduced GST for cotton fabrics, State-level textile industry subsidies.

          Handicrafts:
          - GST Slabs: 0% (Traditional handicrafts and khadi), 5% (Artisan goods).
          - Waivers: Market promotion schemes for handicrafts, GST exemption on bamboo products.

          State-specific benefits:
          Tamil Nadu: 15%-25% capital subsidies, Refund of state GST for MSMEs, Subsidized industrial land rates.
          Maharashtra: 5% interest subsidies, Stamp duty exemptions, Lower electricity tariffs for MSMEs.
          Uttar Pradesh: 20% capital investment subsidy, Wage subsidies for local workers.`,
            },
          ],
        },
      ],
    }

    const response = await axios.post(API_URL, query, {
      headers: { "Content-Type": "application/json" },
    })

    const suggestions = response.data.candidates[0].content.parts[0].text

    return NextResponse.json({ output: suggestions })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}


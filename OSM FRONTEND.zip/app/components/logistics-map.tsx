"use client"

import { useEffect, useRef, useState } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

export function LogisticsMap() {
  const mapRef = useRef(null)
  const [map, setMap] = useState(null)
  const [startCoordinates, setStartCoordinates] = useState("13.0827,80.2707")
  const [endCoordinates, setEndCoordinates] = useState("13.0500,80.2824")
  const [currentRoute, setCurrentRoute] = useState(null)

  useEffect(() => {
    if (typeof window !== "undefined" && mapRef.current && !map) {
      const newMap = L.map(mapRef.current).setView([13.0827, 80.2707], 13)

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "© OpenStreetMap contributors",
      }).addTo(newMap)

      setMap(newMap)
    }
  }, [map])

  const findRoute = async () => {
    if (!map) return

    const start = startCoordinates.split(",").map(Number)
    const end = endCoordinates.split(",").map(Number)

    if (start.length !== 2 || end.length !== 2 || start.some(isNaN) || end.some(isNaN)) {
      alert("Please enter valid coordinates for Start and Destination!")
      return
    }

    try {
      const apiKey = "YOUR_API_KEY" // Replace with your OpenRouteService API key
      const url = `https://api.openrouteservice.org/v2/directions/driving-car?api_key=${apiKey}&start=${start[1]},${start[0]}&end=${end[1]},${end[0]}`

      const response = await fetch(url)
      if (!response.ok) throw new Error("Failed to fetch route data")

      const data = await response.json()
      const coordinates = data.features[0].geometry.coordinates.map((coord) => [coord[1], coord[0]])

      if (currentRoute) {
        map.removeLayer(currentRoute)
      }

      const newRoute = L.polyline(coordinates, { color: "blue", weight: 5 }).addTo(map)
      setCurrentRoute(newRoute)

      map.fitBounds(newRoute.getBounds())
    } catch (error) {
      console.error("Error:", error)
      alert("Failed to fetch the route. Please try again.")
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="start-coordinates">Start (Lat,Lng)</Label>
          <Input
            id="start-coordinates"
            value={startCoordinates}
            onChange={(e) => setStartCoordinates(e.target.value)}
            placeholder="13.0827,80.2707"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="end-coordinates">Destination (Lat,Lng)</Label>
          <Input
            id="end-coordinates"
            value={endCoordinates}
            onChange={(e) => setEndCoordinates(e.target.value)}
            placeholder="13.0500,80.2824"
          />
        </div>
      </div>
      <Button onClick={findRoute} className="w-full">
        Find Route
      </Button>
      <div ref={mapRef} className="h-[400px] w-full rounded-lg shadow-lg" />
    </div>
  )
}


"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChartIcon, DollarSignIcon, BuildingIcon, MapPinIcon } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// MongoDB setup (this should be done on the server-side in a real application)
const MONGODB_URL = "mongodb+srv://chorkoccse2023:11281058@cluster0.b0nh98b.mongodb.net/"
const DB_NAME = "sme_waiver"
const COLLECTION_NAME = "user_details"

// Google Gemini API setup
const API_KEY = "AIzaSyCTvpqoQvxzUEEdrKVwe88wGHwePryWxj4"
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`

export function MarketAnalysis() {
  const [output, setOutput] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [businessSector, setBusinessSector] = useState("")
  const [annualTurnover, setAnnualTurnover] = useState("")
  const [subsidies, setSubsidies] = useState("")
  const [state, setState] = useState("")

  const runAnalysis = async () => {
    setIsLoading(true)
    setError("")
    setOutput("")
    try {
      // In a real application, this should be a server-side API call
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessSector,
          annualTurnover,
          subsidies,
          state,
        }),
      })
      const data = await response.json()
      if (response.ok) {
        setOutput(data.output)
      } else {
        setError(data.error || "An error occurred while running the analysis.")
      }
    } catch (error) {
      console.error("Error running analysis:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="business-sector" className="flex items-center space-x-2">
            <BarChartIcon className="w-4 h-4" />
            <span>Business Sector</span>
          </Label>
          <Select onValueChange={setBusinessSector}>
            <SelectTrigger id="business-sector">
              <SelectValue placeholder="Select business sector" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="food">Food Industry</SelectItem>
              <SelectItem value="textiles">Textiles</SelectItem>
              <SelectItem value="tech">Technology</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="annual-turnover" className="flex items-center space-x-2">
            <DollarSignIcon className="w-4 h-4" />
            <span>Annual Turnover (INR)</span>
          </Label>
          <Input
            type="number"
            id="annual-turnover"
            placeholder="Enter amount"
            value={annualTurnover}
            onChange={(e) => setAnnualTurnover(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="subsidies" className="flex items-center space-x-2">
            <BuildingIcon className="w-4 h-4" />
            <span>Availing Government Subsidies?</span>
          </Label>
          <Select onValueChange={setSubsidies}>
            <SelectTrigger id="subsidies">
              <SelectValue placeholder="Select option" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="yes">Yes</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="state" className="flex items-center space-x-2">
            <MapPinIcon className="w-4 h-4" />
            <span>State</span>
          </Label>
          <Select onValueChange={setState}>
            <SelectTrigger id="state">
              <SelectValue placeholder="Select state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tamil-nadu">Tamil Nadu</SelectItem>
              <SelectItem value="maharashtra">Maharashtra</SelectItem>
              <SelectItem value="karnataka">Karnataka</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button onClick={runAnalysis} className="w-full" disabled={isLoading}>
        {isLoading ? "Running Analysis..." : "Run Analysis"}
      </Button>
      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {output && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow-lg border border-indigo-200">
          <h3 className="font-bold mb-2 text-indigo-700">Analysis Output:</h3>
          <pre className="whitespace-pre-wrap text-sm">{output}</pre>
        </div>
      )}
    </div>
  )
}


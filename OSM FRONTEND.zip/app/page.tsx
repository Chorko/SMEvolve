"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LogisticsMap } from "./components/logistics-map"
import { MarketAnalysis } from "./components/market-analysis"
import { TruckIcon, TrendingUpIcon } from "lucide-react"

export default function SMEvolve() {
  const [activeTab, setActiveTab] = useState("logistics")

  return (
    <div className="container mx-auto p-4 bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
      <h1 className="text-4xl font-bold mb-6 text-center text-indigo-800 py-4">
        SMEvolve
        <span className="text-2xl block font-normal text-indigo-600">Empowering Your Business Growth</span>
      </h1>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
          <TabsTrigger value="logistics" className="flex items-center justify-center space-x-2">
            <TruckIcon className="w-5 h-5" />
            <span>Logistics</span>
          </TabsTrigger>
          <TabsTrigger value="market-analysis" className="flex items-center justify-center space-x-2">
            <TrendingUpIcon className="w-5 h-5" />
            <span>Market Analysis</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="logistics">
          <Card className="border-2 border-indigo-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-indigo-700">
                <TruckIcon className="w-6 h-6" />
                <span>Logistics Tool</span>
              </CardTitle>
              <CardDescription>Plan and optimize your logistics operations</CardDescription>
            </CardHeader>
            <CardContent>
              <LogisticsMap />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="market-analysis">
          <Card className="border-2 border-indigo-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-indigo-700">
                <TrendingUpIcon className="w-6 h-6" />
                <span>Market Analysis & Financial Strategy</span>
              </CardTitle>
              <CardDescription>Analyze market trends and optimize your financial strategy</CardDescription>
            </CardHeader>
            <CardContent>
              <MarketAnalysis />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

